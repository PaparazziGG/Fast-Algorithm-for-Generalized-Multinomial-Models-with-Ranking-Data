jii<-function(number)
{
  Transfer<-function(Data,Response)
  {
    W_Indicator<-Data==1
    L_Indicator<-Data==-1
    P_Indicator<-Data!=0
    
    single_select<-apply(W_Indicator,1,sum)==1
    multi_select<-apply(W_Indicator,1,sum)!=1
    part_candidator<-apply(P_Indicator,1,prod)==0
    a<-rep(0,ncol(Data))
    b<-0
    Delta<-matrix(-1,nrow = 1,ncol=ncol(Data))
    if(sum(single_select)!=0)
    {a<-(t(W_Indicator[single_select,]*Response[single_select])%*%rep(1,sum(single_select)))[,1]}
    if(sum(multi_select)+sum(part_candidator)!=0)
    {b<-c(Response[multi_select],-Response[part_candidator])
    Delta<-rbind(W_Indicator[multi_select,],P_Indicator[part_candidator,])}
    
    return(list(Win=W_Indicator,Loss=L_Indicator,Participant=P_Indicator,a=a,b=b,Delta=Delta))
  }
  
  Bayesian_weaver<-function(a,b,Delta,tol=1e-6)
  {
    gamma<-sum(abs(b))
    p_0_Weaver<-0
    p_1_Weaver<-rep(1/length(a),length(a))
    path_Weaver<-NULL
    path_Weaver<-rbind(path_Weaver,p_1_Weaver)
    k_Weaver<-0
    s=sum(a)+sum(b)
    
    while(sqrt(sum((p_1_Weaver-p_0_Weaver)^2))>tol)
    {
      p_0_Weaver<-p_1_Weaver
      tau<-b/((Delta%*%p_0_Weaver)[,1])
      p_1_Weaver<-(a+p_0_Weaver*gamma)/(s+gamma-(t(Delta)%*%tau)[,1])
      p_1_Weaver<-p_1_Weaver/sum(p_1_Weaver)
      k_Weaver<-k_Weaver+1
      path_Weaver<-rbind(path_Weaver,p_1_Weaver)
    }
    return(list(Estimator=p_1_Weaver,Iteration=k_Weaver,Path=path_Weaver))
  }
  
  MC<-function(W,L,P,Response,tol=1e-6)
  {
    library(DTMCPack)
    p_0_MC<-0
    p_1_MC<-rep(1/ncol(P),ncol(P))
    path_MC<-NULL
    path_MC<-rbind(path_MC,p_1_MC)
    k_MC<-0
    while(sqrt(sum((p_1_MC-p_0_MC)^2))>tol)
    {
      #Sigma<-matrix(0,nrow = 6,ncol = 6)
      p_0_MC<-p_1_MC
      Sigma<-(p_0_MC*t(W))%*%((Response/(W%*%p_0_MC)[,1]/(P%*%p_0_MC)[,1])*L)
      
      sum_Sigma<-(t(rep(1,ncol(P)))%*%Sigma)[1,]
      diag(Sigma)<-mean(sum_Sigma)-sum_Sigma
      Sigma<-Sigma/sum(Sigma)*ncol(Sigma)
      
      p_1_MC<-statdistr(t(Sigma))[1,]
      
      path_MC<-rbind(path_MC,p_1_MC)
      k_MC<-k_MC+1
    }
    return(list(Estimator=p_1_MC,Iteration=k_MC,Path=path_MC))
  }
  EM<-function(a,b,Delta,tol=1e-6)
  {
    p_0_Weaver<-0
    p_1_Weaver<-rep(1/length(a),length(a))
    path_Weaver<-NULL
    path_Weaver<-rbind(path_Weaver,p_1_Weaver)
    k_Weaver<-0
    s=sum(a)+sum(b)
    
    while(sqrt(sum((p_0_Weaver-p_1_Weaver)^2))>tol)
    {
      p_0_Weaver<-p_1_Weaver
      tau<-b/((Delta%*%p_0_Weaver)[,1])
      p_1_Weaver<-(a+((p_0_Weaver*t(Delta))%*%tau)[,1])/s
      p_1_Weaver<-p_1_Weaver/sum(p_1_Weaver)
      k_Weaver<-k_Weaver+1
      path_Weaver<-rbind(path_Weaver,p_1_Weaver)
    }
    return(list(Estimator=p_1_Weaver,Iteration=k_Weaver,Path=path_Weaver))
  }
  Iter<-NULL
  for(size in 2:16)
  {
    p<-rexp(8*size,rate=rep(1:2,each=4*size))
    p<-p/sum(p)
    for(iteration in 1:number)
    {
      Data<-matrix(-1,nrow=1000,ncol = 8*size)
      Response<-rep(1,1000)
      uu<-runif(1000)
      for(k in 1:1000)
      {
        ind<-matrix(sample(1:(8*size),8*size),nrow = 8)
        pp<-cumsum(apply(ind,2,function(x){sum(p[x])}))
        Data[k,ind[,which.min(pp>uu[k])]]<-1
      }
      TransferResult<-Transfer(Data,Response)
      MM.fit<-EM(TransferResult$a,TransferResult$b,TransferResult$Delta)
      Bweaver.fit<-Bayesian_weaver(TransferResult$a,TransferResult$b,TransferResult$Delta)
      MC.fit<-MC(TransferResult$Win,TransferResult$Loss,TransferResult$Participant,Response)
      Iter<-rbind(Iter,c(8*size,MM.fit$Iteration,Bweaver.fit$Iteration,MC.fit$Iteration))
    }
  }
  Iter
}


library(foreach)
library(doParallel)
cl <- makeCluster(5)
registerDoParallel(cl)

wosai<- foreach(number=rep(20,5),.combine='rbind') %dopar% jii(number)
stopCluster(cl)
write.csv(wosai,"item2.csv")

D2<-read.csv("item2.csv")[,-1]
Iter2<-NULL
for(i in 2:16*8)
{
  Iter2<-rbind(Iter2,apply(D2[D2[,1]==i,],2,mean))
}