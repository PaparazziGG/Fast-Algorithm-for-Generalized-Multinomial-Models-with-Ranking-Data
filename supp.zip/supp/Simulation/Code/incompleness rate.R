set.seed(455)
p<-rexp(8,rate=rep(1:2,each=4))
p<-p/sum(p)

WA<-NULL
for(iteration in 0:99)
{
  Iter<-NULL
  for(oo in 1:100)
  {
    Data<-matrix(0,nrow=280,ncol = 8)
    Response<-rep(1,280)
    Strength<-rbeta(280,iteration*0.06,6-iteration*0.06)
    kl<-rbinom(rep(1,280),6,Strength)+2
    for (j in 1:280) 
    {
      wa<-sample(1:8,kl[j])
      rr<-rmultinom(1,1,p[wa]/sum(p[wa]))
      Data[j,wa]<--1+2*rr[,1]
    }
    TransferResult<-Transfer(Data,Response)
    MM.fit<-MM(TransferResult$a,TransferResult$b,TransferResult$Delta)
    weaver.fit<-weaver(TransferResult$a,TransferResult$b,TransferResult$Delta)
    Bweaver.fit<-Bayesian_weaver(TransferResult$a,TransferResult$b,TransferResult$Delta)
    MC.fit<-MC(TransferResult$Win,TransferResult$Loss,TransferResult$Participant,Response)
    Iter<-rbind(Iter,c(MM.fit$Iteration,weaver.fit$Iteration,Bweaver.fit$Iteration,MC.fit$Iteration))
    print(100*(iteration-1)+oo)
  }
  WA<-rbind(WA,c(2+iteration*0.06,apply(Iter,2,median),apply(Iter,2,mean),apply(Iter,2,sd)))
}
X<-WA[,1]/8
plot(0,0,type="n",xlim = range(X),ylim = range(WA[,2:5+4]+2*WA[,2:5+8]),xlab = "Ratio",ylab = "Number of iterations",main="")
for(i in 1:4)
{
  lines(X,WA[,i+5],col=i+1)
  lines(X,WA[,i+5]+2*WA[,i+9],col=i+1,lty=2)
  lines(X,WA[,i+5]-2*WA[,i+9],col=i+1,lty=2)
}
par(las=1)
legend("topright",legend = c("MM","Weaver","Bayesian Weaver","Markov chain"),col=2:5,lty = rep(1,4))

###########################################################################
set.seed(4355)
p<-rexp(128,rate=rep(1:2,each=64))
p<-p/sum(p)

for(i in 1:7)
{
  Iter<-NULL
  for(iteration in 1:100)
  {
    Data<-matrix(-1,nrow=1000,ncol = 128)
    Response<-rep(1,1000)
    uu<-runif(1000)
    for(k in 1:1000)
    {
      ind<-matrix(sample(1:128,128),nrow = 2^i)
      pp<-cumsum(apply(ind,2,function(x){sum(p[x])}))
      Data[k,ind[,which.min(pp>uu[k])]]<-1
    }
    TransferResult<-Transfer(Data,Response)
    MM.fit<-EM(TransferResult$a,TransferResult$b,TransferResult$Delta)
    Bweaver.fit<-Bayesian_weaver(TransferResult$a,TransferResult$b,TransferResult$Delta)
    MC.fit<-MC(TransferResult$Win,TransferResult$Loss,TransferResult$Participant,Response)
    Iter<-rbind(Iter,c(MM.fit$Iteration,Bweaver.fit$Iteration,MC.fit$Iteration))
    print(100*(i-1)+iteration)
  }
  WA<-rbind(WA,c(2^i,apply(Iter,2,mean),apply(Iter,2,sd)))
}

D<-read.csv("incompleteii.csv")[,-1]
WA<-NULL
for(i in 1:3)
{
  WA<-c(WA,D[,i])
}
n<-factor(rep(rep(2^(1:6),each=100),3))
Al<-factor(rep(c("MM","Bayesian Weaver","MC"),each=600),levels = c("MM","Bayesian Weaver","MC"))
DD<-data.frame(iteration=WA,n=n,Algorithm=Al)
boxplot(iteration ~ Al + n, data = DD,
        at = rep(1:3,6)+rep(4*(0:5),each=3), col = 2:4,
        names = c("", "1/64", "", "", "1/32", "", "", "8", "", "", "16", "", "", "32", "", "", "64", ""),xaxt="n",xlab="Number of basic cells in each candidate set",ylab="Number of iterations")
legend("topleft", fill = 2:4, legend = c("MM","Bayesian Weaver","Markov chain"), horiz = F)
par(las=1)
axis(
  side=1,
  at=2+4*(0:5),
  tck=0,
  labels=2^(1:6)
)