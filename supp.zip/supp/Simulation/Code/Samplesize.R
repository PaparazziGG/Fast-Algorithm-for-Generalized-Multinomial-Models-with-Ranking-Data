set.seed(455)
p<-rexp(8,rate=rep(1:2,each=4))
p<-p/sum(p)
par(mfrow=c(1,1))
#Case II
Data<-matrix(0,nrow=choose(8,3)*3,ncol = 8)
KK<-combn(8,3)
for(i in 1:choose(8,3))
{
  for(j in 1:3)
  {
    Data[3*i-3+j,KK[j,i]]<-1
    Data[3*i-3+j,KK[-j,i]]<--1
  }
}
WA<-NULL
Al<-NULL
n<-NULL
for(k in 0:4)
{
  RR<-NULL
  for(i in 1:choose(8,3))
  {
    RR<-rbind(RR,rmultinom(100,5*2^k,prob = p[KK[,i]]/sum(p[KK[,i]])))
  }
  for(iteration in 1:100)
  {
    Response<-RR[,iteration]
    TransferResult<-Transfer(Data,Response)
    MM.fit<-MM(TransferResult$a,TransferResult$b,TransferResult$Delta)
    Bweaver.fit<-Bayesian_weaver(TransferResult$a,TransferResult$b,TransferResult$Delta)
    MC.fit<-MC(TransferResult$Win,TransferResult$Loss,TransferResult$Participant,Response)
    WA<-c(WA,c(MM.fit$Iteration,Bweaver.fit$Iteration,MC.fit$Iteration))
    Al<-c(Al,c("MM","Bayesian Weaver","MC"))
    n<-c(n,rep(280*2^k,3))
    print(100*k+iteration)
  }
}
n<-factor(n)
Al<-factor(Al,,levels = c("MM","Bayesian Weaver","MC"))
DD<-data.frame(iteration=WA,n=n,Algorithm=Al)
par(las=1)
boxplot(iteration ~n+ Algorithm  , data = DD,
        at = rep((1:3-1)*5,each=5)+rep(c(0:4)+1,3), col = rep(2:4,each=5),
        names = as.character(rep(280*2^(0:4),3)),xaxt="n",xlab="Sample size",ylab="Number of iterations",main="Case II")
legend("topleft", fill = 2:4, legend = c("MM","Bayesian Weaver","Markov chain"), horiz = F)
par(las=3)
axis(
  side=1,
  at=rep((1:3-1)*5,each=5)+rep(c(0:4)+1,3),
  tck=0,
  labels=rep(280*2^(0:4),3),
)


#Case III
Data<-matrix(0,nrow=choose(8,4),ncol = 8)
KK<-combn(8,4)
for(i in 1:(choose(8,4)/2)-1)
{
  Data[2*i+1,KK[,i+1]]<-1
  Data[2*i+1,-KK[,i+1]]<--1
  Data[2*i+2,KK[,i+1]]<--1
  Data[2*i+2,-KK[,i+1]]<-1
}
WA<-NULL
Al<-NULL
n<-NULL
for(k in 0:4)
{
  RR<-NULL
  Iter<-NULL
  for(i in 1:(choose(8,4)/2)-1)
  {
    RR<-rbind(RR,rmultinom(100,8*2^k,prob = ((Data[2*i+1:2,]==1)%*%p)[,1]))
  }
  for(iteration in 1:100)
  {
    Response<-RR[,iteration]
    TransferResult<-Transfer(Data,Response)
    MM.fit<-EM(TransferResult$a,TransferResult$b,TransferResult$Delta)
    Bweaver.fit<-Bayesian_weaver(TransferResult$a,TransferResult$b,TransferResult$Delta)
    MC.fit<-MC(TransferResult$Win,TransferResult$Loss,TransferResult$Participant,Response)
    WA<-c(WA,c(MM.fit$Iteration,Bweaver.fit$Iteration,MC.fit$Iteration))
    Al<-c(Al,c("MM","Bayesian Weaver","MC"))
    n<-c(n,rep(280*2^k,3))
    print(100*k+iteration)
  }
}
n<-factor(n)
Al<-factor(Al,,levels = c("MM","Bayesian Weaver","MC"))
DD<-data.frame(iteration=WA,n=n,Algorithm=Al)
par(las=1)
boxplot(iteration ~n+ Algorithm  , data = DD,
        at = rep((1:3-1)*5,each=5)+rep(c(0:4)+1,3), col = rep(2:4,each=5),
        names = as.character(rep(280*2^(0:4),3)),xaxt="n",xlab="Sample size",ylab="Number of iterations",main="Case III")
legend("topleft", fill = 2:4, legend = c("MM","Bayesian Weaver","Markov chain"), horiz = F)
par(las=3)
axis(
  side=1,
  at=rep((1:3-1)*5,each=5)+rep(c(0:4)+1,3),
  tck=0,
  labels=rep(280*2^(0:4),3),
)