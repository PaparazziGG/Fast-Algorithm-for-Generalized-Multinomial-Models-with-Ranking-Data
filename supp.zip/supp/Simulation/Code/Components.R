set.seed(455)
p<-rexp(8,rate=rep(1:2,each=4))
p<-p/sum(p)

#Case A
Data<-matrix(0,nrow=choose(8,3)*3,ncol = 8)
KK<-combn(8,3)
for(i in 1:choose(8,3))
{
  for(j in 1:3)
  {
    Data[3*i-3+j,KK[j,i]]<-1
    Data[3*i-3+j,KK[-j,i]]<--1
  }
}
Iter1<-NULL
RR<-NULL
for(i in 1:choose(8,3))
{
  RR<-rbind(RR,rmultinom(1000,5,prob = p[KK[,i]]/sum(p[KK[,i]])))
}
for(iteration in 1:100)
{
  Response<-RR[,iteration]
  TransferResult<-Transfer(Data,Response)
  MM.fit<-MM(TransferResult$a,TransferResult$b,TransferResult$Delta)
  Bweaver.fit<-Bayesian_weaver(TransferResult$a,TransferResult$b,TransferResult$Delta)
  MC.fit<-MC(TransferResult$Win,TransferResult$Loss,TransferResult$Participant,Response)
  Iter1<-rbind(Iter1,c(MM.fit$Iteration,Bweaver.fit$Iteration,MC.fit$Iteration))
}


#Case B
Data<-matrix(0,nrow=choose(8,3)*3,ncol = 8)
KK<-combn(8,3)
for(i in 1:choose(8,3))
{
  for(j in 1:3)
  {
    Data[3*i-3+j,KK[j,i]]<-1
    Data[3*i-3+j,KK[-j,i]]<--1
  }
}
Iter2<-NULL
RR<-NULL
for(i in 1:choose(8,3))
{
  RR<-rbind(RR,rmultinom(1000,10,prob = p[KK[,i]]/sum(p[KK[,i]])))
}
DD<-NULL
Response<-NULL
for(iteration in 1:100)
{
  ind<-sample(1:56,28)
  DD<-Data[rep(ind*3,each=3)-3+rep(1:3,28),]
  Response<-RR[rep(ind*3,each=3)-3+rep(1:3,28),iteration]
  TransferResult<-Transfer(DD,Response)
  MM.fit<-MM(TransferResult$a,TransferResult$b,TransferResult$Delta)
  Bweaver.fit<-Bayesian_weaver(TransferResult$a,TransferResult$b,TransferResult$Delta)
  MC.fit<-MC(TransferResult$Win,TransferResult$Loss,TransferResult$Participant,Response)
  Iter2<-rbind(Iter2,c(MM.fit$Iteration,Bweaver.fit$Iteration,MC.fit$Iteration))
}

#Case C
Data<-matrix(0,nrow=choose(8,3)*3,ncol = 8)
KK<-combn(8,3)
for(i in 1:choose(8,3))
{
  for(j in 1:3)
  {
    Data[3*i-3+j,KK[j,i]]<-1
    Data[3*i-3+j,KK[-j,i]]<--1
  }
}
Iter3<-NULL
RR<-NULL
for(i in 1:choose(8,3))
{
  RR<-rbind(RR,rmultinom(1000,20,prob = p[KK[,i]]/sum(p[KK[,i]])))
}
DD<-NULL
Response<-NULL
for(iteration in 1:100)
{
  ind<-sample(1:56,14)
  DD<-Data[rep(ind*3,each=3)-3+rep(1:3,14),]
  Response<-RR[rep(ind*3,each=3)-3+rep(1:3,14),iteration]
  TransferResult<-Transfer(DD,Response)
  MM.fit<-MM(TransferResult$a,TransferResult$b,TransferResult$Delta)
  Bweaver.fit<-Bayesian_weaver(TransferResult$a,TransferResult$b,TransferResult$Delta)
  MC.fit<-MC(TransferResult$Win,TransferResult$Loss,TransferResult$Participant,Response)
  Iter3<-rbind(Iter3,c(MM.fit$Iteration,Bweaver.fit$Iteration,MC.fit$Iteration))
}
Iter<-NULL
Al<-factor(rep(c("MM","Bayesian Weaver","MC"),each=300),levels = c("MM","Bayesian Weaver","MC"))
case<-rep(factor(rep(c("IIA","IIB","IIC"),each=100)),3)
for(i in 1:3)
{
  Iter<-c(Iter,Iter1[,i])
  Iter<-c(Iter,Iter2[,i])
  Iter<-c(Iter,Iter3[,i])
}
DD<-data.frame(iteration=Iter,case=case,Algorithm=Al)
par(las=1)
boxplot(iteration ~ case + Algorithm, data = DD,
        at = rep(1:3,3)+rep(4*(0:2),each=3), col = rep(2:4,each=3),
        names = c("", "IIA", "", "", "IIB", "", "", "IIC", ""),xaxt="n",xlab="Subcase",ylab="Number of iterations")
legend("topleft", fill = 2:4, legend = c("MM","Bayesian Weaver","Markov chain"), horiz = F)
axis(
  side=1,
  at=rep(1:3,3)+rep(4*(0:2),each=3),
  tck=0,
  labels=rep(c("IIA","IIB","IIC"),3)
)
