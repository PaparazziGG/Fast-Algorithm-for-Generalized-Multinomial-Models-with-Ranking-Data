set.seed(455)
p<-rexp(8,rate=rep(1:2,each=4))
p<-p/sum(p)

#Case I
CaseIkl<-NULL
CaseImd<-NULL
Data<-matrix(-1,nrow = 8,ncol = 8)+diag(rep(2,8))
W<-diag(rep(1,8))
P<-matrix(1,nrow = 8,ncol = 8)
for(k in 0:9)
{
  Response<-t(rmultinom(1000,280*2^k,p))
  estimator<-Response/(280*2^k)
  kll<-NULL
  mdd<-NULL
  for(i in 1:1000)
  {
    kll<-c(kll,KL(estimator[i,],p))
    mdd<-c(mdd,Mdist(estimator[i,],p,W,P,Response[i,]))
    print(i)
  }
  CaseIkl<-rbind(CaseIkl,c(k,kll))
  CaseImd<-rbind(CaseImd,c(k,mdd))
}
write.csv(CaseIkl,"CaseIkl.csv")
write.csv(CaseImd,"CaseImd.csv")

#Case II
CaseIIkl<-NULL
CaseIImd<-NULL
Data<-matrix(0,nrow=choose(8,3)*3,ncol = 8)
KK<-combn(8,3)
for(i in 1:choose(8,3))
{
  for(j in 1:3)
  {
    Data[3*i-3+j,KK[j,i]]<-1
    Data[3*i-3+j,KK[-j,i]]<--1
  }
}
for(k in 0:9)
{
  RR<-NULL
  kll<-NULL
  mdd<-NULL
  klla<-NULL
  mdda<-NULL
  for(i in 1:choose(8,3))
  {
    RR<-rbind(RR,rmultinom(1000,5*2^k,prob = p[KK[,i]]/sum(p[KK[,i]])))
  }
  for(iteration in 1:1000)
  {
    Response<-RR[,iteration]
    TransferResult<-Transfer(Data,Response)
    MC.fit<-MC(TransferResult$Win,TransferResult$Loss,TransferResult$Participant,Response)
    kll<-c(kll,KL(MC.fit$Estimator,p))
    mdd<-c(mdd,Mdist(MC.fit$Estimator,p,TransferResult$Win,TransferResult$Participant,Response))
    print(iteration)
  }
  CaseIIkl<-rbind(CaseIIkl,c(k,kll))
  CaseIImd<-rbind(CaseIImd,c(k,mdd))
}
write.csv(CaseIIkl,"CaseIIkl.csv")
write.csv(CaseIImd,"CaseIImd.csv")

#Case III
CaseIIIkl<-NULL
CaseIIImd<-NULL
Data<-matrix(0,nrow=choose(8,4),ncol = 8)
KK<-combn(8,4)
for(i in 1:(choose(8,4)/2)-1)
{
  Data[2*i+1,KK[,i+1]]<-1
  Data[2*i+1,-KK[,i+1]]<--1
  Data[2*i+2,KK[,i+1]]<--1
  Data[2*i+2,-KK[,i+1]]<-1
}
for(k in 0:9)
{
  RR<-NULL
  kll<-NULL
  mdd<-NULL
  for(i in 1:(choose(8,4)/2)-1)
  {
    RR<-rbind(RR,rmultinom(1000,8*2^k,prob = ((Data[2*i+1:2,]==1)%*%p)[,1]))
  }
  for(iteration in 1:1000)
  {
    Response<-RR[,iteration]
    TransferResult<-Transfer(Data,Response)
    MC.fit<-MC(TransferResult$Win,TransferResult$Loss,TransferResult$Participant,Response)
    kll<-c(kll,KL(MC.fit$Estimator,p))
    mdd<-c(mdd,Mdist(MC.fit$Estimator,p,TransferResult$Win,TransferResult$Participant,Response))
    print(iteration)
  }
  CaseIIIkl<-rbind(CaseIIIkl,c(k,kll))
  CaseIIImd<-rbind(CaseIIImd,c(k,mdd))
}
write.csv(CaseIIIkl,"CaseIIIkl.csv")
write.csv(CaseIIImd,"CaseIIImd.csv")

#Case IV
CaseIVkl<-NULL
CaseIVmd<-NULL
Data<-matrix(0,nrow=choose(8,6)*choose(6,3),ncol = 8)
KK<-combn(8,6)
LL<-combn(6,3)
k<-0
for(i in 1:choose(8,6))
{
  for(j in 1:(choose(6,3)/2))
  {
    k<-k+1
    Data[k,KK[LL[,j],i]]<-1
    Data[k,KK[-LL[,j],i]]<--1
    k<-k+1
    Data[k,KK[LL[,j],i]]<--1
    Data[k,KK[-LL[,j],i]]<-1
  }
}

for(k in 0:9)
{
  RR<-NULL
  kll<-NULL
  mdd<-NULL
  for(i in 1:280-1)
  {
    RR<-rbind(RR,rmultinom(1000,1*2^k,prob = ((Data[2*i+1:2,]==1)%*%p)[,1]/sum((Data[2*i+1:2,]==1)%*%p)))
  }
  for(iteration in 1:1000)
  {
    Response<-RR[,iteration]
    TransferResult<-Transfer(Data,Response)
    MC.fit<-MC(TransferResult$Win,TransferResult$Loss,TransferResult$Participant,Response)
    kll<-c(kll,KL(MC.fit$Estimator,p))
    mdd<-c(mdd,Mdist(MC.fit$Estimator,p,TransferResult$Win,TransferResult$Participant,Response))
    print(iteration)
  }
  CaseIVkl<-rbind(CaseIVkl,c(k,kll))
  CaseIVmd<-rbind(CaseIVmd,c(k,mdd))
}
write.csv(CaseIVkl,"CaseIVkl.csv")
write.csv(CaseIVmd,"CaseIVmd.csv")

summary_KL<-0:9
summary_KL<-cbind(summary_KL,apply(CaseIkl[,-1],1,mean,na.rm=T))
summary_KL<-cbind(summary_KL,apply(CaseIIkl[,-1],1,mean,na.rm=T))
summary_KL<-cbind(summary_KL,apply(CaseIIIkl[,-1],1,mean,na.rm=T))
summary_KL<-cbind(summary_KL,apply(CaseIVkl[,-1],1,mean,na.rm=T))

summary_KL_log<-cbind(0:9,log(summary_KL[,-1]))

par(mfrow=c(1,1))
plot(0,0,xlab = "k",ylab="Log KL--divergence",xlim = range(c(0,9)),ylim=range(summary_KL_log[,-1]))
lines(0:9,summary_KL_log[,2],col=1,type="o",lty=1,pch=15)
lines(0:9,summary_KL_log[,3],col=2,type="o",lty=2,pch=16)
lines(0:9,summary_KL_log[,4],col=3,type="o",lty=3,pch=0)
lines(0:9,summary_KL_log[,5],col=4,type="o",lty=4,pch=1)
legend("topright",col = 1:4,legend = c("I","II","III","IV"),lty=1:4,pch=c(15,16,0,1))

par(mfrow=c(2,2))
ww<-sort(CaseIVmd[1,-1])
plot(0,0,type="n",xlab="Empirical distribution of Mahalanobis--distance",ylab = "CDF of Chisq(7)",xlim=c(0,1),ylim=c(0,1),main = "k=1")
abline(a=0,b=1,lty=2)
lines(1:1000/1000,pchisq(ww,df=7),type = "s",col=2,lwd=1.5)
ww<-sort(CaseIVmd[4,-1])
plot(0,0,type="n",xlab="Empirical distribution of Mahalanobis--distance",ylab = "CDF of Chisq(7)",xlim=c(0,1),ylim=c(0,1),main = "k=4")
abline(a=0,b=1,lty=2)
lines(1:1000/1000,pchisq(ww,df=7),type = "s",col=2,lwd=1.5)
ww<-sort(CaseIVmd[7,-1])
plot(0,0,type="n",xlab="Empirical distribution of Mahalanobis--distance",ylab = "CDF of Chisq(7)",xlim=c(0,1),ylim=c(0,1),main = "k=7")
abline(a=0,b=1,lty=2)
lines(1:1000/1000,pchisq(ww,df=7),type = "s",col=2,lwd=1.5)
ww<-sort(CaseIVmd[10,-1])
plot(0,0,type="n",xlab="Empirical distribution of Mahalanobis--distance",ylab = "CDF of Chisq(7)",xlim=c(0,1),ylim=c(0,1),main = "k=10")
abline(a=0,b=1,lty=2)
lines(1:1000/1000,pchisq(ww,df=7),type = "s",col=2,lwd=1.5)