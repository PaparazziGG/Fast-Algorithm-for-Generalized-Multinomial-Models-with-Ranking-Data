Race<-read.csv("race.csv",header = T)
Short<-Race[,c(1,19,44)]
names(Short)<-c("MatchNo","JTNo","FP")
Short$JTNo<-as.character(Short$JTNo)

W<-list()
P<-list()
keng<-0
for(i in unique(Short$MatchNo))
{
  DD<-Short[Short$MatchNo==i,]
  hey<-sort(unique(DD$FP))
  ding<-length(hey)
  for(j in hey[-ding])
  {
    keng<-keng+1
    W[[keng]]<-DD$JTNo[DD$FP==j]
    P[[keng]]<-DD$JTNo[DD$FP>=j]
  }
}
bugou<-unique(Short$JTNo)
d<-length(bugou)

###################################################################
tol<-1e-6
p_0_Weaver<-0
p_1_Weaver<-rep(1,d)
names(p_1_Weaver)<-bugou
numerator<-0*p_1_Weaver+0.1
k_Weaver<-0
for(i in 1:keng)
{
  if(length(W[[i]])==1)
  {
    numerator[W[[i]]]<-numerator[W[[i]]]+1
  }
}
while(sqrt(sum((p_1_Weaver-p_0_Weaver)^2))>d*tol&&k_Weaver<10000)
{
  p_0_Weaver<-p_1_Weaver
  denominator<-p_0_Weaver*0+0.1
  snumerator<-p_0_Weaver*0
  for(i in 1:keng)
  {
    denominator[P[[i]]]<-denominator[P[[i]]]+1/sum(p_0_Weaver[P[[i]]])
    if(length(W[[i]])!=1)
    {
      snumerator[W[[i]]]<-snumerator[W[[i]]]+p_0_Weaver[W[[i]]]/sum(p_0_Weaver[W[[i]]])
    }
  }
  
  p_1_Weaver<-(numerator+snumerator)/(denominator)
  p_1_Weaver<-p_1_Weaver/sum(p_1_Weaver)*d
  k_Weaver<-k_Weaver+1
  print(k_Weaver)
  print(sqrt(sum((p_1_Weaver-p_0_Weaver)^2)))
  print(d*tol)
}
######################################################
write.csv(c(k_Weaver,p_1_Weaver),"FULLRANKINGJTMM.csv")