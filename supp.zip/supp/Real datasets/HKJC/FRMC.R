Race<-read.csv("race.csv",header = T)
Short<-Race[,c(1,16,44)]
names(Short)<-c("MatchNo","HrBrand","FP")
Short$HrBrand<-as.character(Short$HrBrand)

W<-list()
P<-list()
keng<-0
for(i in unique(Short$MatchNo))
{
  DD<-Short[Short$MatchNo==i,]
  hey<-sort(unique(DD$FP))
  ding<-length(hey)
  for(j in hey[-ding])
  {
    keng<-keng+1
    W[[keng]]<-DD$HrBrand[DD$FP==j]
    P[[keng]]<-DD$HrBrand[DD$FP>=j]
  }
}
bugou<-unique(Short$HrBrand)
d<-length(bugou)

###################################################################
tol<-1e-6
p_0_MC<-0
p_1_MC<-rep(1,d)
names(p_1_MC)<-bugou
k_MC<-0
Sigmabase<-rep(1,d)%*%t(rep(0.1/d,d))
rownames(Sigmabase)<-bugou
colnames(Sigmabase)<-bugou
while(sqrt(sum((p_1_MC-p_0_MC)^2))>d*tol&&k_MC<10000)
{
  p_0_MC<-p_1_MC
  Sigma<-Sigmabase
  for(i in 1:keng)
  {
    Sigma[W[[i]],P[[i]]]<-Sigma[W[[i]],P[[i]]]+p_0_MC[W[[i]]]/sum(p_0_MC[W[[i]]])/sum(p_0_MC[P[[i]]])
  }
  sum_Sigma<-(t(rep(1,d))%*%Sigma)[1,]
  diag(Sigma)<-diag(Sigma)-sum_Sigma
  diag(Sigma)<-diag(Sigma)-min(diag(Sigma))
  Sigma<-Sigma/sum(Sigma)*ncol(Sigma)
  for(times in 1:(2*d))
  {p_1_MC<-(Sigma%*%p_1_MC)[,1]
  #print(times)
  }
  
  k_MC<-k_MC+1
  print(k_MC)
  print(sqrt(sum((p_1_MC-p_0_MC)^2)))
  print(d*tol)
}
######################################################
write.csv(c(k_MC,p_1_MC),"FULLRANKINGMC.csv")