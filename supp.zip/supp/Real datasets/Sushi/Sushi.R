###complete PL
Complete<-read.table("sushicomplete.txt",sep=",",header = F)[,-1]
Data<-NULL
kk<-1:511
ww<-rep(1,511)
for(i in 1:9)
{
  ww<-cbind(rep(1,511),-(kk%%2),ww)
  kk<-floor(kk/2)
}
kk<-2*(0:9)+1
for(i in 1:10)
{
  Data<-rbind(Data,ww[,-kk[-i]])
}
Response<-rep(0,5110)
a<-0
for(a in 1:9)
{
  win<-Complete[,a]
  KK<-Complete[,a:9+1]-(Complete[,a:9+1]>matrix(rep(win,10-a),ncol = 10-a))
  ind<-(win-1)*511+apply(KK-1,1,function(x){sum(2^x)})
  wa<-table(factor(ind))
  Response[as.integer(names(wa))]<-Response[as.integer(names(wa))]+wa
}
Data<-Data[Response!=0,]
Response<-Response[Response!=0]
dd<-data.frame(Data,Response)
write.csv(dd,"sushicompletdeal.csv")

TD<-Transfer(Data,Response)
wa1<-system.time(A1<-Bayesian_weaver(TD$a,TD$b,TD$Delta))
wa2<-system.time(B1<-MC(TD$Win,TD$Loss,TD$Participant,Response))
wa3<-system.time(C1<-MM(TD$a,TD$b,TD$Delta))
Res<-cbind(A1$Estimator,B1$Estimator,C1$Estimator)
Res<-rbind(Res,c(A1$Iteration,B1$Iteration,C1$Iteration),100*c(wa1[3],wa2[3],wa3[3]))
rownames(Res)<-c(as.character(1:10),"iteration","running time")
colnames(Res)<-c("Bayesian Weaver","MC","MM")
write.csv(Res,"Sushicomplete_result_PL.csv")

###incomplete PL
inComplete<-read.table("sushiincomplete.txt",sep=",",header = F)[,-1]
Data<-NULL
KK<-matrix(-1,nrow = nrow(inComplete),ncol = 100)
wa<-1:nrow(inComplete)
for(a in 1:10)
{
  KK[(inComplete[,a]-1)*nrow(inComplete)+wa]<-1
  Data<-rbind(Data,KK)
  KK[(inComplete[,a]-1)*nrow(inComplete)+wa]<-0
}
Response<-rep(1,nrow(Data))
TD<-Transfer(Data,Response)
wa1<-system.time(A1<-Bayesian_weaver(TD$a,TD$b,TD$Delta))
wa2<-system.time(B1<-MC(TD$Win,TD$Loss,TD$Participant,Response))
wa3<-system.time(C1<-MM(TD$a,TD$b,TD$Delta))
Res<-cbind(A1$Estimator,B1$Estimator,C1$Estimator)
Res<-rbind(Res,c(A1$Iteration,B1$Iteration,C1$Iteration),100*c(wa1[3],wa2[3],wa3[3]))
rownames(Res)<-c(as.character(1:100),"iteration","running time")
colnames(Res)<-c("Bayesian Weaver","MC","MM")
write.csv(Res,"Sushiincomplete_result_PL.csv")

###complete BT
Complete<-read.table("sushicomplete.txt",sep=",",header = F)[,-1]
Data<-matrix(0,nrow = 90,ncol = 10)
Response<-rep(0,90)
KK<-combn(10,2)
Ranking<-t(apply(Complete,1,order))
for(i in 1:choose(10,2)-1)
{
  Data[2*i+1,KK[1,i+1]]<-1
  Data[2*i+1,KK[2,i+1]]<--1
  Data[2*i+2,KK[1,i+1]]<--1
  Data[2*i+2,KK[2,i+1]]<-1
  Response[2*i+1]<-sum(Ranking[,KK[1,i+1]]<Ranking[,KK[2,i+1]])
  Response[2*i+2]<-sum(Ranking[,KK[1,i+1]]>Ranking[,KK[2,i+1]])
}
TD<-Transfer(Data,Response)
wa1<-system.time(A1<-Bayesian_weaver(TD$a,TD$b,TD$Delta))
wa2<-system.time(B1<-MC(TD$Win,TD$Loss,TD$Participant,Response))
wa3<-system.time(C1<-MM(TD$a,TD$b,TD$Delta))
Res<-cbind(A1$Estimator,B1$Estimator,C1$Estimator)
Res<-rbind(Res,c(A1$Iteration,B1$Iteration,C1$Iteration),100*c(wa1[3],wa2[3],wa3[3]))
rownames(Res)<-c(as.character(1:10),"iteration","running time")
colnames(Res)<-c("Bayesian Weaver","MC","MM")
write.csv(Res,"Sushicomplete_result_BT.csv")

pathMM<-log(apply(C1$Path[-(C1$Iteration+1),],1,function(x){sum((x-C1$Estimator)^2)}))
pathBW<-log(apply(A1$Path[-(A1$Iteration+1),],1,function(x){sum((x-A1$Estimator)^2)}))
pathMC<-log(apply(B1$Path[-(B1$Iteration+1),],1,function(x){sum((x-B1$Estimator)^2)}))
plot(0,0,type="n",xlab = "Iteration",ylab = "log-SSE",xlim = range(1:A1$Iteration-1),ylim = range(c(pathMM,pathBW,pathMC)),main="")
lines(0:(nrow(A1$Path)-2),pathBW,col=3,lty=2,lwd=2)
lines(0:(nrow(B1$Path)-2),pathMC,col=4,lty=3,lwd=2)
lines(0:(nrow(C1$Path)-2),pathMM,col=2,lty=1,lwd=2)
legend("topright",legend = c("MM","(Bayesian) Weaver","Markov chain"),col = 2:4,lty=1:3)

###incomplete BT
inComplete<-read.table("sushiincomplete.txt",sep=",",header = F)[,-1]
Data<-matrix(0,nrow = 9900,ncol = 100)
Response<-rep(0,9900)
KK<-combn(100,2)
Ranking<-matrix(11,nrow = nrow(inComplete),ncol = 100)
wa<-1:nrow(inComplete)
for(a in 1:10)
{
  Ranking[(inComplete[,a]-1)*nrow(inComplete)+wa]<-a
}
for(i in 1:choose(100,2)-1)
{
  Data[2*i+1,KK[1,i+1]]<-1
  Data[2*i+1,KK[2,i+1]]<--1
  Data[2*i+2,KK[1,i+1]]<--1
  Data[2*i+2,KK[2,i+1]]<-1
  Response[2*i+1]<-sum(Ranking[,KK[1,i+1]]<Ranking[,KK[2,i+1]])
  Response[2*i+2]<-sum(Ranking[,KK[1,i+1]]>Ranking[,KK[2,i+1]])
}
Data<-Data[Response!=0,]
Response<-Response[Response!=0]

TD<-Transfer(Data,Response)
wa1<-system.time(A1<-Bayesian_weaver(TD$a,TD$b,TD$Delta))
wa2<-system.time(B1<-MC(TD$Win,TD$Loss,TD$Participant,Response))
wa3<-system.time(C1<-MM(TD$a,TD$b,TD$Delta))
Res<-cbind(A1$Estimator,B1$Estimator,C1$Estimator)
Res<-rbind(Res,c(A1$Iteration,B1$Iteration,C1$Iteration),100*c(wa1[3],wa2[3],wa3[3]))
rownames(Res)<-c(as.character(1:100),"iteration","running time")
colnames(Res)<-c("Bayesian Weaver","MC","MM")
write.csv(Res,"Sushiincomplete_result_BT.csv")

#Composite cell
iji<-list()
for(k in 2:3)
{
  Complete<-read.table("sushicomplete.txt",sep=",",header = F)[,-1]
  Data<-matrix(-1,nrow = nrow(Complete),ncol = 10)
  wa<-1:nrow(Complete)
  for(a in 1:k)
  {
    Data[(Complete[,a]-1)*nrow(Complete)+wa]<-1
  }
  Response<-rep(1,nrow(Data))
  TD<-Transfer(Data,Response)
  a<-TD$a
  b<-TD$b
  Delta<-TD$Delta
  wa1<-system.time(A1<-Bayesian_weaver2(TD$a,TD$b,TD$Delta))
  wa2<-system.time(B1<-MC(TD$Win,TD$Loss,TD$Participant,Response))
  wa3<-system.time(C1<-EM(TD$a,TD$b,TD$Delta))
  Res<-cbind(A1$Estimator,B1$Estimator,C1$Estimator)
  Res<-rbind(Res,c(A1$Iteration,B1$Iteration,C1$Iteration),100*c(wa1[3],wa2[3],wa3[3]))
  rownames(Res)<-c(as.character(1:10),"iteration","running time")
  colnames(Res)<-c("Bayesian Weaver","MC","MM")
  iji[[k-1]]<-Res
}
for(k in 4:8)
{
  Complete<-read.table("sushicomplete.txt",sep=",",header = F)[,-1]
  Data<-matrix(-1,nrow = nrow(Complete),ncol = 10)
  wa<-1:nrow(Complete)
  for(a in 1:k)
  {
    Data[(Complete[,a]-1)*nrow(Complete)+wa]<-1
  }
  Response<-rep(1,nrow(Data))
  TD<-Transfer(Data,Response)
  a<-TD$a
  b<-TD$b
  Delta<-TD$Delta
  wa1<-system.time(A1<-Bayesian_weaver(TD$a,TD$b,TD$Delta))
  wa2<-system.time(B1<-MC(TD$Win,TD$Loss,TD$Participant,Response))
  wa3<-system.time(C1<-EM(TD$a,TD$b,TD$Delta))
  Res<-cbind(A1$Estimator,B1$Estimator,C1$Estimator)
  Res<-rbind(Res,c(A1$Iteration,B1$Iteration,C1$Iteration),100*c(wa1[3],wa2[3],wa3[3]))
  rownames(Res)<-c(as.character(1:10),"iteration","running time")
  colnames(Res)<-c("Bayesian Weaver","MC","MM")
  iji[[k-1]]<-Res
}

#write.csv(Res,"Sushiincomplete_result_subset.csv")