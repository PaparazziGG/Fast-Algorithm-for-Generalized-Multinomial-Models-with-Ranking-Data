library(PlackettLuce)
data("nascar")
R <- as.rankings(nascar, input = "ordering")
D<-nascar[,1:43]

#PL
Data<-matrix(0,nrow = nrow(D)*(ncol(D)-1),ncol = 87)
k<-1
for(j in 1:nrow(D))
{
  for(i in 1:(ncol(D)-1))
  {
    Data[k,D[j,i:ncol(D)]]<--1
    Data[k,D[j,i]]<-1
    k<-k+1
  }
}
Response<-rep(1,nrow(Data))

TD<-Transfer(Data,Response)
wa1<-system.time(A1<-Bayesian_weaver(TD$a,TD$b,TD$Delta))
wa2<-system.time(B1<-MC(TD$Win,TD$Loss,TD$Participant,Response))
wa3<-system.time(C1<-MM(TD$a,TD$b,TD$Delta))
Res<-cbind(A1$Estimator,B1$Estimator,C1$Estimator)
Res<-rbind(Res,c(A1$Iteration,B1$Iteration,C1$Iteration),c(wa1[3],wa2[3],wa3[3]))
rownames(Res)<-c(as.character(1:87),"iteration","running time")
colnames(Res)<-c("Bayesian Weaver","MC","MM")
write.csv(Res,"Nascar_result_PL1.csv")
OO<-order(A1$Estimator,decreasing = T)
KK<-cbind(OO,Res[OO,])
colnames(KK)<-c("No.","Bayesian Weaver","MC","MM")
write.csv(KK,"Nascar_result_PL2.csv")
JJ<-cbind(KK[1:29,c(1,3)],KK[1:29+29,c(1,3)],KK[1:29+58,c(1,3)])
JJ[,c(2,4,6)]<-round(JJ[,c(2,4,6)],4)
colnames(JJ)[c(2,4,6)]<-"MLE"
write.table(JJ,"NASCAR.txt",sep = "&")

kkA<-apply(A1$Path[1:21,],1,function(x){sum((x-A1$Estimator)^2)})
kkB<-apply(B1$Path[-nrow(B1$Path),],1,function(x){sum((x-B1$Estimator)^2)})
kkC<-apply(C1$Path[-nrow(C1$Path),],1,function(x){sum((x-C1$Estimator)^2)})
plot(0,0,type = "n",xlab = "Iteration",ylab = "log-SSE",xlim = range(0:20),ylim = range(log(c(kkA,kkB[],kkC[]))),main="")
lines(0:20,log(kkA),col=3,lty=2,lwd=2)
lines(0:(nrow(B1$Path)-2),log(kkB),col=4,lty=3,lwd=2)
lines(0:(nrow(C1$Path)-2),log(kkC),col=2,lty=1,lwd=2)
legend("bottomright",legend = c("MM","(Bayesian) Weaver","Markov chain"),col = 2:4,lty=1:3)
write.csv(t(B1$Path),"PathNascar.csv")

##############################################################################
#BT
Data1<-NULL
for(j in 1:(ncol(D)-1))
{
  for(i in (j+1):(ncol(D)))
  {
    QQ<-matrix(0,ncol = 87,nrow = nrow(D))
    QQ[D[,j]*nrow(D)+1-(nrow(D):1)]<-1
    QQ[D[,i]*nrow(D)+1-(nrow(D):1)]<--1
    Data1<-rbind(Data1,QQ)
  }
}
Response1<-rep(1,nrow(Data1))

TD<-Transfer(Data1,Response1)
a<-TD$a
b<-TD$b
Delta<-TD$Delta
wa1<-system.time(A1<-Bayesian_weaver(TD$a,TD$b,TD$Delta,tol = 1e-4))
wa2<-system.time(B1<-MC(TD$Win,TD$Loss,TD$Participant,Response,tol = 1e-4))
wa3<-system.time(C1<-MM(TD$a,TD$b,TD$Delta,tol = 1e-4))
Res<-cbind(A1$Estimator,B1$Estimator,C1$Estimator)
Res<-rbind(Res,c(A1$Iteration,B1$Iteration,C1$Iteration),c(wa1[3],wa2[3],wa3[3]))
rownames(Res)<-c(as.character(1:87),"iteration","running time")
colnames(Res)<-c("Bayesian Weaver","MC","MM")
write.csv(Res,"Nascar_result_BT1.csv")
OO<-order(A1$Estimator,decreasing = T)
KK<-cbind(OO,Res[OO,])
colnames(KK)<-c("No.","Bayesian Weaver","MC","MM")
write.csv(KK,"Nascar_result_BT2.csv")
